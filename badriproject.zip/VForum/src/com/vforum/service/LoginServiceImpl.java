package com.vforum.service;

import java.sql.SQLException;

import com.vforum.dao.LoginDAO;
import com.vforum.exception.UserException;
import com.vforum.model.LoginModel;

public class LoginServiceImpl implements LoginService{
	
	LoginDAO loginDAO=null;
	
	public LoginServiceImpl() { }

	@Override
	public String userAuthenticationService(LoginModel loginModel)throws ClassNotFoundException,SQLException {
		// TODO Auto-generated method stub
		
		String result="fail";
			boolean userValid=loginDAO.userAuth(loginModel.getUserId(),loginModel.getPassword());
			if(userValid){
				result="success";}
			else{
				 throw new UserException("Invalid username or password");}
		
		return result;
	}

	
}
