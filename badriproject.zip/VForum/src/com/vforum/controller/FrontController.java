package com.vforum.controller;

import java.sql.SQLException;

import com.vforum.exception.UserException;
import com.vforum.model.LoginModel;
import com.vforum.service.LoginService;
//import com.vforum.view.EmployeesView;
import com.vforum.view.ErrorView;
import com.vforum.view.MainView;

public class FrontController {

	
	private LoginService loginService;
	public void userAuthentication(String userId,String password)throws ClassNotFoundException,SQLException {
		
		LoginModel loginModel=new LoginModel();
		loginModel.setUserId(userId);
		loginModel.setPassword(password);
		try {
			String result=loginService.userAuthenticationService(loginModel);
		if(result=="success"){
			MainView mainView=new MainView();
			mainView.employeeMenu();
		}
		else{
			ErrorView errorView=new ErrorView();
			errorView.authenticationError();
		}
			
	}
		catch(UserException e)
		{
			System.out.println("User Authentication failed.");
		}
}
}
