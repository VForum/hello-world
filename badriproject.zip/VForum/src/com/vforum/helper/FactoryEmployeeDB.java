package com.vforum.helper;

import com.vforum.dao.EmployeesDAO;
import com.vforum.dao.EmployeesDAOImpl;
import com.vforum.service.EmployeesService;
import com.vforum.service.EmployeesServiceImpl;

public class FactoryEmployeeDB {

	public static EmployeesDAO createEmployeesDAO(){
		EmployeesDAO employeesDAO=new EmployeesDAOImpl();
		return employeesDAO;
		
	}
	public static EmployeesService createEmployeesService(){
		EmployeesService employeesService=
				new EmployeesServiceImpl();
		return employeesService;
	}

}
