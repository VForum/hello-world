package com.vforum.view;

public class ErrorView {
	
public void authenticationError() {
		
		System.out.println("=======Failed ! wrong details ======");
	}

}
