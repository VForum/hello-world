package com.vforum.view;

public class AdminView {

public void mainAdminView() {
		
		System.out.println("=======Admin View======");
		System.out.println("1. view employees ");
		System.out.println("2.search ");
		System.out.println("3.delete post ");
	}
}
