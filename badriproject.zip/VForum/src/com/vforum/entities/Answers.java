package com.vforum.entities;

public class Answers {

}
