package com.vforum.view;

public class MainView {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
