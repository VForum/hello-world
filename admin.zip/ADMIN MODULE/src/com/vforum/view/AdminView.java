package com.vforum.view;

import java.util.List;
import java.util.Scanner;

import com.vforum.controller.AdminController;
import com.vforum.model.EmployeeModel;

public class AdminView {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\n");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your choice");
		System.out.println("1.view employee details");
		System.out.println("2.exit");
		int option=sc.nextInt();
		
		if(option==1)
		{
			
		}
		
	}
		
}
