package com.vforum.controller;

import java.util.List;

import com.vforum.model.EmployeeModel;
import com.vforum.view.AdminView;
import com.virtusa.helper.FactoryClass;
import com.virtusa.service.AdminService;

public class AdminController {
AdminView adminView=new AdminView();
private AdminService adminService;
public AdminController()
{
	this.adminService=FactoryClass.createAdminService();
}
public void getEmployeeInfo(EmployeeModel model)
{

}
}
