package com.virtusa.helper;

import com.vforum.dao.AdminDao;
import com.vforum.dao.JdbcAdminDaoImpl;
import com.virtusa.service.AdminService;
import com.virtusa.service.AdminServiceImpl;

public class FactoryClass {

	public static AdminDao createAdminDao(){
		AdminDao adminDao=new JdbcAdminDaoImpl();
		return adminDao;
		
	}
	public static AdminService createAdminService(){
		AdminService adminService=
				new AdminServiceImpl();
		return adminService;
	}
}
