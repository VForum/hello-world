package com.virtusa.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.vforum.dao.AdminDao;
import com.vforum.entities.Employees;
import com.vforum.model.EmployeeModel;
import com.virtusa.helper.FactoryClass;

public class AdminServiceImpl implements AdminService {
private AdminDao adminDao;
public AdminServiceImpl () {
	this.adminDao=FactoryClass.createAdminDao();
}
	@Override
	public List<EmployeeModel> retrieveEmployees() {
		List<EmployeeModel> employeesModelList=new ArrayList<>();
		// TODO Auto-generated method stub
		try {
			List<Employees> employeesList=adminDao.getEmployeeDetails();
			for(Employees employees:employeesList) {
				EmployeeModel employeesModel=new EmployeeModel();
				employeesModel.setEmployeeId(employees.getEmployeeId());
				employeesModel.setFirstName(employees.getFirstName());
				employeesModel.setLastName(employees.getLastName());
				employeesModel.setEmailId(employees.getEmailId());
				employeesModel.setPhoneNumber(employees.getPhoneNumber());
				employeesModelList.add(employeesModel);
				
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return employeesModelList;
		
	}

}
