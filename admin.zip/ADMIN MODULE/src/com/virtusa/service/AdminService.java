package com.virtusa.service;

import java.util.List;

import com.vforum.model.EmployeeModel;

public interface AdminService {
	public List<EmployeeModel> retrieveEmployees();
}
