package com.vforum.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.vforum.services.AdminServiceIface;
import com.vforum.services.AdminServiceImpl;

/**
 * Servlet implementation class DeleteAnswerAdminController
 */
public class DeleteAnswerAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int qid=Integer.parseInt(request.getParameter("qid"));
		AdminServiceIface ad=new AdminServiceImpl();
		request.setAttribute("deletedans", ad.reportActionDelAns(qid));
		response.sendRedirect("AdminIndex.jsp");
	}

}
