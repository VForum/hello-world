package com.vforum.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.vforum.services.UserServiceIface;
import com.vforum.services.UserServiceImpl;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String email = request.getParameter("email");
		String pas = request.getParameter("psw");
		UserServiceIface u = new UserServiceImpl();
		if (email != null && pas != null) {
			if (email.compareTo("admin@virtusa.com") == 0 && pas.compareTo("Admin@123") == 0) {
				session.setAttribute("email", "admin");
				response.sendRedirect("AdminIndex.jsp");
			} else {

				if (u.Login(email, pas)) {
					session.setAttribute("email", email);
					session.setAttribute("password", pas);
					response.sendRedirect("Main.jsp");
				} else {
					request.setAttribute("message", "Invalid Credentials!");
					RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);
				}
			}
		}
		
	}

}
