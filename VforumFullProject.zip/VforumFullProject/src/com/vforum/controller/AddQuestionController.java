package com.vforum.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.vforum.model.Questions;
import com.vforum.services.QuestionServiceIface;
import com.vforum.services.QuestionServiceImpl;
import com.vforum.services.UserServiceImpl;

/**
 * Servlet implementation class AddQuestionController
 */
public class AddQuestionController extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		Questions q=new Questions();
		QuestionServiceIface qdao=new QuestionServiceImpl();
		q.setUserId(new UserServiceImpl().getUserIdfromemail((String)session.getAttribute("email")));
		q.setQuestion(request.getParameter("question"));
		q.setTitle(request.getParameter("categories"));
		qdao.postQuestion(q);
		response.sendRedirect((request.getParameter("categories")).substring(0,1).toUpperCase()+request.getParameter("categories").substring(1)+".jsp");
	}

}
