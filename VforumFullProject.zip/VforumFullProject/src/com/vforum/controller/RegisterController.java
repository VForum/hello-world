package com.vforum.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.vforum.model.User;
import com.vforum.services.UserServiceIface;
import com.vforum.services.UserServiceImpl;

/**
 * Servlet implementation class RegisterController
 */
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = new User();
		UserServiceIface ud=new UserServiceImpl();
			user.setUserId(ud.generateUserId());
			user.setFirstname(request.getParameter("uname"));
			user.setEmail(request.getParameter("email"));
			user.setPassword(request.getParameter("psw"));
			user.setPhoneno(Long.parseLong(request.getParameter("mobno")));
			user.setDesig(request.getParameter("desig"));
		ud.createuser(user);
		response.sendRedirect("Login.jsp");
	}

}
