package com.vforum.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.vforum.services.ReportServiceIface;
import com.vforum.services.ReportServiceImpl;

/**
 * Servlet implementation class ReportQuestionController
 */
public class ReportAnswerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ReportServiceIface rdao=new ReportServiceImpl();
		int q_id=Integer.parseInt(request.getParameter("qid"));
		String report_statement=request.getParameter("rptAns");
		int Ans_id=Integer.parseInt(request.getParameter("aid"));
		boolean flag=rdao.reportAnswer(report_statement, q_id, Ans_id);
		if(flag){
		response.sendRedirect("Main.jsp");
		}
		else
		{
		response.sendRedirect("Main.jsp");
		}
	}

}
