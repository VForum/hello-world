package com.vforum.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.vforum.services.AdminServiceIface;
import com.vforum.services.AdminServiceImpl;

/**
 * Servlet implementation class DeleteQuestionAdminController
 */
public class DeleteQuestionAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int qid=Integer.parseInt(req.getParameter("qid"));
		AdminServiceIface ad=new AdminServiceImpl();
		ad.reportActionDel(qid);
		resp.sendRedirect("AdminIndex.jsp");
		}
}
