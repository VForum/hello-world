package com.vforum.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.vforum.services.AnswerServiceIface;
import com.vforum.services.AnswerServiceImpl;
import com.vforum.services.UserServiceImpl;

/**
 * Servlet implementation class AddAnswerController
 */
public class AddAnswerController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		AnswerServiceIface user = new AnswerServiceImpl();
		HttpSession session = request.getSession();
		user.answerQuestion(Integer.parseInt(request.getParameter("qid")),
				new UserServiceImpl().getUserIdfromemail((String) session.getAttribute("email")),
				request.getParameter("answer"));
		response.sendRedirect("Main.jsp");
	}

}
