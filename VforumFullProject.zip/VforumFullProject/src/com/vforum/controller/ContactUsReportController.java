package com.vforum.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.vforum.daos.UserDao;
import com.vforum.model.Report;
import com.vforum.services.ContactServiceIface;
import com.vforum.services.ContactServiceImpl;

/**
 * Servlet implementation class ContactUsReportController
 */
public class ContactUsReportController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ContactServiceIface contactDao = new ContactServiceImpl();
		Report rt = new Report();
		rt.setUid(new UserDao().getUserIdfromemail(request.getParameter("email")));
		rt.setUname(request.getParameter("name"));
		rt.setEmail(request.getParameter("email"));
		rt.setCtitle(request.getParameter("complain"));
		rt.setDescription(request.getParameter("Description"));
		contactDao.Contact(rt);
		request.setAttribute("message", "Thank you for contacting us , we'll reach back to you soon !");
		request.setAttribute("addCallSnackbar", "snackBarFunction()");
		RequestDispatcher rd=request.getRequestDispatcher("Contact.jsp");
		rd.forward(request, response);
	}

}
