package com.vforum.util;

import java.sql.Connection;
import org.apache.log4j.Logger;

import java.util.ResourceBundle;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DaoConnection {
	static Logger logger = Logger.getLogger(DaoConnection.class);

	public static Connection getConnection() {
		Connection connection = null;
		ResourceBundle resource = ResourceBundle.getBundle("com/vforum/resources/db");
		String path = resource.getString("DB_DRIVER_CLASS");
		String url = resource.getString("DB_URL");
		String user = resource.getString("DB_USERNAME");
		String pwd = resource.getString("DB_PASSWORD");
		try {
			Class.forName(path);
			connection = DriverManager.getConnection(url, user, pwd);
		} catch (ClassNotFoundException e) {
			logger.error(e.getMessage());
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return connection;

	}

}
