package com.vforum.model;

import java.sql.Date;

public class PostAnswers {
	private String usernameanswer;
	private String answer;
	private Date answerdate;
	private int ansid;

	public String getUsernameanswer() {
		return usernameanswer;
	}

	public void setUsernameanswer(String usernameanswer) {
		this.usernameanswer = usernameanswer;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Date getAnswerdate() {
		return answerdate;
	}

	public void setAnswerdate(Date answerdate) {
		this.answerdate = answerdate;
	}

	public int getAnsid() {
		return ansid;
	}

	public void setAnsid(int ansid) {
		this.ansid = ansid;
	}

}
