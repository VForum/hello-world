package com.vforum.services;

import java.util.ArrayList;

import com.vforum.model.PostQuestions;
import com.vforum.model.Questions;

public interface QuestionServiceIface {
	public int generateQuestionId();

	public ArrayList<PostQuestions> allrecentques();

	public ArrayList<PostQuestions> allsearchques(String search);

	public String postQuestion(Questions obj);

	public ArrayList<PostQuestions> viewAllQuestionCat(String category);

	public ArrayList<PostQuestions> viewAllQuestionUid(int uid);
}
