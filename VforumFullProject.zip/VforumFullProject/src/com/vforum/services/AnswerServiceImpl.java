package com.vforum.services;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.vforum.daos.AnswerDao;
import com.vforum.daos.AnswerDaoIface;
import com.vforum.model.PostAnswers;
import com.vforum.model.Questions;

public class AnswerServiceImpl implements AnswerServiceIface {
	AnswerDaoIface answerDaoIface = null;

	public AnswerServiceImpl() {
		answerDaoIface = new AnswerDao();
	}

	@Override
	public int generateAnswerId() {
		return answerDaoIface.generateAnswerId();
	}

	@Override
	public ArrayList<PostAnswers> allrecentquesanswers(int qid) {

		return answerDaoIface.allrecentquesanswers(qid);
	}

	@Override
	public ArrayList<Questions> viewQuestion(int uid) {

		return answerDaoIface.viewQuestion(uid);
	}

	@Override
	public void answerQuestion(int quesid, int userid, String answer) {
		answerDaoIface.answerQuestion(quesid, userid, answer);
	}

	@Override
	public ResultSet viewAllAnswersWithQuesUid(int uid) {
		return answerDaoIface.viewAllAnswersWithQuesUid(uid);
	}

}
