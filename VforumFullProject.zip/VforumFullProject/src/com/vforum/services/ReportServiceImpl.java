package com.vforum.services;

import com.vforum.daos.ReportDao;
import com.vforum.daos.ReportDaoIface;

public class ReportServiceImpl implements ReportServiceIface {
	ReportDaoIface reportDaoIface = null;

	public ReportServiceImpl() {
		reportDaoIface = new ReportDao();
	}

	@Override
	public int generateReportId() {

		return reportDaoIface.generateReportId();
	}

	@Override
	public void reportQuestion(String report_statement, int ques_id) {

		reportDaoIface.reportQuestion(report_statement, ques_id);
	}

	@Override
	public int generateAnswerReportId() {

		return reportDaoIface.generateAnswerReportId();
	}

	@Override
	public boolean reportAnswer(String reportstatement, int quesid, int ansid) {

		return reportDaoIface.reportAnswer(reportstatement, quesid, ansid);
	}

}
