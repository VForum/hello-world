package com.vforum.services;

import com.vforum.model.Report;

public interface ContactServiceIface {
	public String Contact(Report rs);
}
