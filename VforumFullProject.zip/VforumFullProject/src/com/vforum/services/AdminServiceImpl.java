package com.vforum.services;

import java.util.ArrayList;

import com.vforum.daos.AdminDao;
import com.vforum.daos.AdminDaoIface;
import com.vforum.model.Contactus;
import com.vforum.model.ReportedQuestions;
import com.vforum.model.User;

public class AdminServiceImpl implements AdminServiceIface {
	AdminDaoIface adminDaoIface = null;

	public AdminServiceImpl() {
		adminDaoIface = new AdminDao();
	}

	@Override
	public ArrayList<ReportedQuestions> getAllReportedQues() {
		return adminDaoIface.getAllReportedQues();
	}

	@Override
	public ArrayList<ReportedQuestions> getAllReportedAns() {

		return adminDaoIface.getAllReportedAns();
	}

	@Override
	public ArrayList<User> getAllUser() {

		return adminDaoIface.getAllUser();
	}

	@Override
	public String reportActionDel(int qid) {

		return adminDaoIface.reportActionDel(qid);
	}

	@Override
	public String reportActionDelAns(int aid) {

		return adminDaoIface.reportActionDelAns(aid);
	}

	@Override
	public ArrayList<Contactus> getAllCotactUs() {

		return adminDaoIface.getAllCotactUs();
	}

}
