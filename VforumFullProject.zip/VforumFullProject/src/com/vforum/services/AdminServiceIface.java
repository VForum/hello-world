package com.vforum.services;

import java.util.ArrayList;

import com.vforum.model.Contactus;
import com.vforum.model.ReportedQuestions;
import com.vforum.model.User;

public interface AdminServiceIface {
	public ArrayList<ReportedQuestions> getAllReportedQues();

	public ArrayList<ReportedQuestions> getAllReportedAns();

	public ArrayList<User> getAllUser();

	public String reportActionDel(int qid);

	public String reportActionDelAns(int aid);

	public ArrayList<Contactus> getAllCotactUs();
}
