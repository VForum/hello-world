package com.vforum.services;

import com.vforum.model.User;

public interface UserServiceIface {
	public int generateUserId();

	public boolean CheckEmail(String email);

	public String createuser(User user);

	public boolean Login(String email, String pass);

	public User changePassword(String pass, String email);

	public User viewProfile(int uid);

	public boolean ConfirmPassword(String newpwd, String cnfpwd);

	public int getUserIdfromemail(String email);
}
