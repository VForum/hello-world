package com.vforum.services;

import java.util.ArrayList;

import com.vforum.daos.QuestionDao;
import com.vforum.daos.QuestionDaoIface;
import com.vforum.model.PostQuestions;
import com.vforum.model.Questions;

public class QuestionServiceImpl implements QuestionServiceIface {
	QuestionDaoIface questionDaoIface = null;

	public QuestionServiceImpl() {
		questionDaoIface = new QuestionDao();
	}

	@Override
	public int generateQuestionId() {

		return questionDaoIface.generateQuestionId();
	}

	@Override
	public ArrayList<PostQuestions> allrecentques() {

		return questionDaoIface.allrecentques();
	}

	@Override
	public ArrayList<PostQuestions> allsearchques(String search) {

		return questionDaoIface.allsearchques(search);
	}

	@Override
	public String postQuestion(Questions obj) {

		return questionDaoIface.postQuestion(obj);
	}

	@Override
	public ArrayList<PostQuestions> viewAllQuestionCat(String category) {

		return questionDaoIface.viewAllQuestionCat(category);
	}

	@Override
	public ArrayList<PostQuestions> viewAllQuestionUid(int uid) {

		return questionDaoIface.viewAllQuestionUid(uid);
	}

}
