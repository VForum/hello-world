package com.vforum.services;

import com.vforum.daos.UserDao;
import com.vforum.daos.UserDaoIface;
import com.vforum.model.User;

public class UserServiceImpl implements UserServiceIface {
	UserDaoIface userDaoIface = null;

	public UserServiceImpl() {
		userDaoIface = new UserDao();
	}

	@Override
	public int generateUserId() {

		return userDaoIface.generateUserId();
	}

	@Override
	public boolean CheckEmail(String email) {

		return userDaoIface.CheckEmail(email);
	}

	@Override
	public String createuser(User user) {

		return userDaoIface.createuser(user);
	}

	@Override
	public boolean Login(String email, String pass) {

		return userDaoIface.Login(email, pass);
	}

	@Override
	public User changePassword(String pass, String email) {

		return userDaoIface.changePassword(pass, email);
	}

	@Override
	public User viewProfile(int uid) {

		return userDaoIface.viewProfile(uid);
	}

	@Override
	public boolean ConfirmPassword(String newpwd, String cnfpwd) {

		return userDaoIface.ConfirmPassword(newpwd, cnfpwd);
	}

	@Override
	public int getUserIdfromemail(String email) {

		return userDaoIface.getUserIdfromemail(email);
	}

}
