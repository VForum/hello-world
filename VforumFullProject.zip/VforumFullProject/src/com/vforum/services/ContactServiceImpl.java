package com.vforum.services;

import com.vforum.daos.ContactDao;
import com.vforum.daos.ContactDaoIface;
import com.vforum.model.Report;

public class ContactServiceImpl implements ContactServiceIface {
	ContactDaoIface contactDaoIface = null;

	public ContactServiceImpl() {
		contactDaoIface = new ContactDao();
	}

	@Override
	public String Contact(Report rs) {
		return contactDaoIface.Contact(rs);
	}

}
