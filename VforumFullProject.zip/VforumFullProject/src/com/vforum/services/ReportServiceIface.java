package com.vforum.services;

public interface ReportServiceIface {
	public int generateReportId();

	public void reportQuestion(String report_statement, int ques_id);

	public int generateAnswerReportId();

	public boolean reportAnswer(String reportstatement, int quesid, int ansid);
}
