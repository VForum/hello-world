package com.vforum.daos;

public interface ReportDaoIface {
	public int generateReportId();

	public void reportQuestion(String report_statement, int ques_id);

	public int generateAnswerReportId();

	public boolean reportAnswer(String reportstatement, int quesid, int ansid);
}
