package com.vforum.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.vforum.model.Report;
import com.vforum.util.DaoConnection;

public class ContactDao implements ContactDaoIface{
	Connection connection=null;
	PreparedStatement preparedStatement=null;
	static Logger logger=Logger.getLogger(ContactDao.class);
	
	public ContactDao() {
		connection = DaoConnection.getConnection();
		if(connection!=null) {
			try {
				connection.setAutoCommit(false);
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}
	public String Contact(Report rs) {
		String s=null;
		try {
			String cmd = "insert into contactus (u_id,uname,email,c_title,description) values(?,?,?,?,?) ";
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setInt(1, rs.getUid());
			preparedStatement.setString(2, rs.getUname());
			preparedStatement.setString(3, rs.getEmail());
			preparedStatement.setString(4, rs.getCtitle());
			preparedStatement.setString(5, rs.getDescription());
			int p=preparedStatement.executeUpdate();
			if(p>0) {
				s="report created";
				connection.commit();
				
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			s= e.getMessage();
		}

		return s;
	}
}
