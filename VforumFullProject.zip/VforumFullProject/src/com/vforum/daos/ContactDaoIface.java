package com.vforum.daos;

import com.vforum.model.Report;

public interface ContactDaoIface {
	public String Contact(Report rs);
}
