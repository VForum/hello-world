package com.vforum.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.vforum.model.PostAnswers;
import com.vforum.model.Questions;
import com.vforum.util.DaoConnection;

public class AnswerDao implements AnswerDaoIface{
	
	Connection connection=null;
	static PreparedStatement preparedStatement=null;
	static Logger logger=Logger.getLogger(UserDao.class);
	
	public AnswerDao() {
		connection = DaoConnection.getConnection();
		if(connection!=null) {
			try {
				connection.setAutoCommit(false);
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}
	
	public int generateAnswerId() {
		int ansid=0;
		String cmd = "select CASE when max(ans_id) is null then 1 Else max(ans_id)+1 END ans_id from answers";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			ResultSet rs = preparedStatement.executeQuery();
			if(rs.next()) {
				ansid= rs.getInt("ans_id");
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return ansid;
	}
	
	public ArrayList<PostAnswers> allrecentquesanswers(int qid) {
		connection = DaoConnection.getConnection();
		ArrayList<PostAnswers> allQuestions = new ArrayList<PostAnswers>();
		String cmd = "\r\n"
				+ "select u.uname,a.answer_text,a.date_answered,a.ans_id from users u inner join answers a on u.u_id=a.u_id where a.ques_id=?";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setInt(1, qid);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				PostAnswers ques = new PostAnswers();
				ques.setUsernameanswer(rs.getString(1));
				ques.setAnswer(rs.getString(2));
				ques.setAnswerdate(rs.getDate(3));
				ques.setAnsid(rs.getInt(4));
				allQuestions.add(ques);
			}
		} catch (SQLException e) {

			logger.error(e.getMessage());
		}
		return allQuestions;
	}
	
	public ArrayList<Questions> viewQuestion(int uid) {
		ArrayList<Questions> all_ques_user_asked = new ArrayList<Questions>();
		String cmd = "select * from questions where u_id=?";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setInt(1, uid);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Questions ques = new Questions();
				ques.setQuestionId(rs.getInt("ques_id"));
				ques.setQuestion(rs.getString("ques"));
				ques.setTitle(rs.getString("title"));
				ques.setDatecreated(rs.getDate("date_created"));
				ques.setDateUpdated(rs.getDate("date_update"));
				all_ques_user_asked.add(ques);
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return all_ques_user_asked;
	}
	public void answerQuestion(int quesid, int userid, String answer) {
		String cmd = "insert into answers (ques_id,u_id,answer_text,ans_id) values(?,?,?,?)";
		int aid = this.generateAnswerId();
		try {
			PreparedStatement pst = connection.prepareStatement(cmd);
			pst.setInt(1, quesid);
			pst.setInt(2, userid);
			pst.setString(3, "<pre>"+answer+"</pre>");
			pst.setInt(4, aid);
			int p=pst.executeUpdate();
			if(p>0) {
				connection.commit();
				
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
	}
	
	public ResultSet viewAllAnswersWithQuesUid(int uid) {
		ResultSet rs = null;
		String cmd = "select u.uname uname,u.designation designation,q.ques_id ques_id,q.ques ques,q.title title,q.date_created date_created,q.date_update date_update,a.answer_text answer_text,a.date_answered date_answered from questions q inner join users u on u.u_id=q.u_id inner join answers a on a.ques_id=q.ques_id where a.u_id=? order by q.ques_id desc";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setInt(1, uid);
			rs = preparedStatement.executeQuery();
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}

		return rs;
	}
}
