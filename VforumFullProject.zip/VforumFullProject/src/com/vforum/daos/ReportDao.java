package com.vforum.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import com.vforum.util.DaoConnection;

public class ReportDao implements ReportDaoIface {
	static Connection connection = null;
	static PreparedStatement preparedStatement = null;
	static Logger logger = Logger.getLogger(UserDao.class);

	public ReportDao() {
		connection = DaoConnection.getConnection();
		if (connection != null) {
			try {
				connection.setAutoCommit(false);
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}

	public int generateReportId() {
		int report_id = 0;
		String cmd = "select CASE when max(report_id) is null then 1 Else max(report_id)+1 END report_id from report_Question";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				report_id = rs.getInt("report_id");

			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return 0;
		}
		return report_id;
	}

	public void reportQuestion(String report_statement, int ques_id) {

		String cmd = "insert into report_question(report_id,report_statement,ques_id) values(?,?,?)";
		int n = generateReportId();
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setInt(1, n);
			preparedStatement.setString(2, report_statement);
			preparedStatement.setInt(3, ques_id);
			int p = preparedStatement.executeUpdate();
			if (p > 0) {
				connection.commit();

			}
		} catch (SQLException e) {
			logger.error(e.getMessage());

		}
	}

	public int generateAnswerReportId() {
		int reportid = 0;
		String cmd = "select CASE when max(report_id) is null then 1 Else max(report_id)+1 END report_id from report_Answer";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				reportid = rs.getInt("report_id");

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
			return 0;
		}
		return reportid;
	}

	public boolean reportAnswer(String reportstatement, int quesid, int ansid) {
		boolean check = false;
		String cmd = "insert into report_Answer(report_id,report_statement,ques_id,ans_id) values(?,?,?,?)";
		int n = generateAnswerReportId();
		try {
			PreparedStatement pst = connection.prepareStatement(cmd);
			pst.setInt(1, n);
			pst.setString(2, reportstatement);
			pst.setInt(3, quesid);
			pst.setInt(4, ansid);
			int p = pst.executeUpdate();
			if (p > 0) {
				check = true;
				connection.commit();

			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return check;
	}

}
