package com.vforum.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.vforum.model.Contactus;
import com.vforum.model.ReportedQuestions;
import com.vforum.model.User;
import com.vforum.util.DaoConnection;

public class AdminDao implements AdminDaoIface {
	Connection connection;
	PreparedStatement preparedStatement;
	
	public AdminDao() {
		connection=DaoConnection.getConnection();
		if(connection!=null) {
			try {
				connection.setAutoCommit(false);
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}
	
	static Logger logger = Logger.getLogger(AdminDao.class);
	
	public ArrayList<ReportedQuestions> getAllReportedQues(){
		
		ArrayList<ReportedQuestions> allRepotedQues=new ArrayList<>();
		ReportedQuestions rq=null;
		String cmd="select r.ques_id ques_id,r.report_statement report_statement,q.ques ques,u.uname uname,u.designation designation,q.date_created date_created " + 
				"from report_question r inner join " + 
				"questions q on q.ques_id=r.ques_id " + 
				"inner join users u on u.u_id=q.u_id";
		try {
			preparedStatement=connection.prepareStatement(cmd);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next()) {
				rq=new ReportedQuestions();
				rq.setQuesId(rs.getInt(1));
				rq.setQuestionReportText(rs.getString(2));
				rq.setQuestionText(rs.getString(3));
				rq.setQuesCreateUser(rs.getString(4));
				rq.setQuesCreateUserDesig(rs.getString(5));
				rq.setQuesCreateDate(rs.getDate(6));
				allRepotedQues.add(rq);
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
		
		}
		return allRepotedQues;
	}
	
	public ArrayList<ReportedQuestions> getAllReportedAns(){
		
		ArrayList<ReportedQuestions> allRepotedAns=new ArrayList<ReportedQuestions>();
		ReportedQuestions rq=null;
		String cmd="select r.ans_id ans_id,r.report_statement report_statement,q.ques ques,a.answer_text answer_text,u.uname uname,u.designation designation,a.date_answered date_created " + 
				"from report_answer r " + 
				"inner join answers a on a.ans_id=r.ans_id " + 
				"inner join questions q on q.ques_id=r.ques_id inner join users u on u.u_id=q.u_id";
		try {
			preparedStatement=connection.prepareStatement(cmd);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next()) {
				rq=new ReportedQuestions();
				rq.setQuesId(rs.getInt(1));
				rq.setQuestionReportText(rs.getString(2));
				rq.setQuestionText(rs.getString(3));
				rq.setAnswerText(rs.getString(4));
				rq.setQuesCreateUser(rs.getString(5));
				rq.setQuesCreateUserDesig(rs.getString(6));
				rq.setQuesCreateDate(rs.getDate(7));
				allRepotedAns.add(rq);
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			
		}
		return allRepotedAns;
	}
	
	public ArrayList<User> getAllUser(){
		
		ArrayList<User> allUsers=new ArrayList<>();
		User obj=null;
		String cmd="select * from users";
		try {
			preparedStatement=connection.prepareStatement(cmd);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next()) {
				obj=new User();
				obj.setUserId(rs.getInt(1));
				obj.setFirstname(rs.getString(2));
				obj.setEmail(rs.getString(3));
				obj.setPassword(rs.getString(4));
				obj.setPhoneno(rs.getLong(5));
				obj.setDesig(rs.getString(6));
				allUsers.add(obj);
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return allUsers;
		
		
	}
	
	public String reportActionDel(int qid) {
		String s=null;
		String cmdReport="delete from report_question where ques_id=?";
		String cmdAnswers="delete from answers where ques_id=?";
		String cmdQuestions="delete from questions where ques_id=?";
		int check=-1;
		try {
			preparedStatement=connection.prepareStatement(cmdReport);
			preparedStatement.setInt(1, qid);
			check=preparedStatement.executeUpdate();
			preparedStatement=connection.prepareStatement(cmdAnswers);
			preparedStatement.setInt(1, qid);
			check=preparedStatement.executeUpdate();
			preparedStatement=connection.prepareStatement(cmdQuestions);
			preparedStatement.setInt(1, qid);
			check=preparedStatement.executeUpdate();
			if(check>0) {
				s= "Question deleted !";
				connection.commit();
				
			}else {
				s="Some Problem Occured while deleting Question!";
				
			}
		} catch (SQLException e) {
			System.out.println(e);
			logger.error(e.getMessage());
		}
		return s;
	}
	
	
	public String reportActionDelAns(int aid) {
		String s=null;
		String cmdReport="delete from report_answer where ans_id=?";
		String cmdAnswers="delete from answers where ans_id=?";
		int check=-1;
		try {
			preparedStatement=connection.prepareStatement(cmdReport);
			preparedStatement.setInt(1, aid);
			check=preparedStatement.executeUpdate();
			preparedStatement=connection.prepareStatement(cmdAnswers);
			preparedStatement.setInt(1, aid);
			check=preparedStatement.executeUpdate();
			if(check>0) {
				s="Answer deleted !";
				connection.commit();
				
			}else {
				s="Some Problem Occured while deleting Question!";
				
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return s;
	}
	
	public ArrayList<Contactus> getAllCotactUs() {
		
		ArrayList<Contactus> cuAll=new ArrayList<Contactus>();
		String cmd="select * from contactus";
		Contactus cu=null;
		try {
			preparedStatement=connection.prepareStatement(cmd);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next()) {
				cu=new Contactus();
				cu.setUserid(rs.getInt(1));
				cu.setUname(rs.getString(2));
				cu.setEmail(rs.getString(3));
				cu.setMsgTitle(rs.getString(4));
				cu.setMsgDesc(rs.getString(5));
				cuAll.add(cu);
			}
			
		} catch (SQLException e) {

			logger.error(e.getMessage());
			
		}
		return cuAll;
		
	}
	
}
