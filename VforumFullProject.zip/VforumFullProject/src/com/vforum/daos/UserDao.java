package com.vforum.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.vforum.model.User;
import com.vforum.util.DaoConnection;

public class UserDao implements UserDaoIface{
	static Connection connection = null;
	static PreparedStatement preparedStatement= null;
	static Logger logger = Logger.getLogger(UserDao.class);

	public UserDao() {
		connection = DaoConnection.getConnection();
		if (connection != null) {
			try {
				connection.setAutoCommit(false);
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}

	public int generateUserId() {
		int u_id = 0;
		String cmd = "select CASE when max(u_id) is null then 1 Else max(u_id)+1 end u from users";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				u_id = rs.getInt("u");
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return u_id;

	}

	public boolean CheckEmail(String email) {
		boolean flag = false;
		int val = 0;
		String cmd = "select count(*) from users where email=?";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setString(1, email);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				val = rs.getInt(1);
				if (val > 0) {
					flag = true;
				}
				
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return flag;
	}

	public String createuser(User user) {
		String s = null;
		String cmd = "insert into users(u_id,uname,email,password,phone,designation)values(?,?,?,?,?,?)";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setInt(1, user.getUserId());
			preparedStatement.setString(2, user.getFirstname());
			preparedStatement.setString(3, user.getEmail());
			preparedStatement.setString(4, user.getPassword());
			preparedStatement.setLong(5, user.getPhoneno());
			preparedStatement.setString(6, user.getDesig());
			int p = preparedStatement.executeUpdate();
			if (p > 0) {
				s = "User created successfully";
				connection.commit();
				
			} else {
				s = "Error generating user";
				
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());

		}
		return s;
	}

	public boolean Login(String email, String pass) {
		boolean flag = false;
		String cmd = "select count(*) from users where email=? AND password=?";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, pass);
			ResultSet rs = preparedStatement.executeQuery();
			rs.next();
			if (rs.getInt(1)>0) {
				flag = true;
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return flag;
	}

	public User changePassword(String pass, String email) {

		User user = null;
		String cmd = "Update users set password=? where email=?";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setString(1, pass);
			preparedStatement.setString(2, email);
			if (preparedStatement.executeUpdate() > 0) {
				connection.commit();
				
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());

		}
		return user;

	}

	public User viewProfile(int uid) {

		User user1 = null;
		String cmd = "select * from users where u_id=?";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setInt(1, uid);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				user1 = new User();
				user1.setFirstname(rs.getString("uname"));
				user1.setDesig(rs.getString("designation"));
				user1.setEmail(rs.getString("email"));
				user1.setPassword(rs.getString("password"));
				user1.setPhoneno(rs.getLong("phone"));
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return user1;
	}

	public boolean ConfirmPassword(String newpwd, String cnfpwd) {

		if (newpwd.equals(cnfpwd)) {
			return true;
		} else {
			return false;
		}
	}

	public int getUserIdfromemail(String email) {
		int quesid = 0;
		String cmd = "select u_id from users where email=?";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setString(1, email);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				quesid = rs.getInt("u_id");
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		return quesid;

	}

}
