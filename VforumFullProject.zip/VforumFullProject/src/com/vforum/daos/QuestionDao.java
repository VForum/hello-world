package com.vforum.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.vforum.model.PostQuestions;
import com.vforum.model.Questions;
import com.vforum.util.DaoConnection;

public class QuestionDao implements QuestionDaoIface {
	 Connection connection=null;
	static PreparedStatement preparedStatement=null;
	static Logger logger=Logger.getLogger(UserDao.class);
	
	public QuestionDao() {
		connection = DaoConnection.getConnection();
		if(connection!=null) {
			try {
				connection.setAutoCommit(false);
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}
	
	public int generateQuestionId() {
		int quesid=0;
		String cmd = "select CASE when max(ques_id) is null then 1 Else max(ques_id)+1 END ques_id from questions";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			ResultSet rs = preparedStatement.executeQuery();
			if(rs.next()) {
				quesid= rs.getInt("ques_id");
				
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			
		}
		return quesid;

	}
	
	public ArrayList<PostQuestions> allrecentques() {
		
		ArrayList<PostQuestions> allQuestions = new ArrayList<PostQuestions>();
		String cmd = "select u.uname uname,u.designation designation,q.ques_id ques_id,q.ques ques,"
				+ "q.title title,q.date_created date_created,q.date_update date_update "
				+ "from questions q inner join users u on u.u_id=q.u_id order by q.ques_id desc";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				PostQuestions ques = new PostQuestions();
				ques.setUsername(rs.getString("uname"));
				ques.setDesig(rs.getString("designation"));
				ques.setQuestionId(rs.getInt("ques_id"));
				ques.setQuestion(rs.getString("ques"));
				ques.setTitle(rs.getString("title"));
				ques.setDatecreated(rs.getDate("date_created"));
				ques.setDateUpdated(rs.getDate("date_update"));
				allQuestions.add(ques);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return allQuestions;
	}
	public ArrayList<PostQuestions> allsearchques(String search) {
		
		ArrayList<PostQuestions> allQuestions = new ArrayList<PostQuestions>();
		String cmd = "select u.uname uname,u.designation designation,q.ques_id ques_id,q.ques ques,q.title title"
				+ ",q.date_created date_created,q.date_update date_update from questions q inner join users u on u.u_id=q.u_id"
				+ " where lower(q.ques) LIKE lower('%'||?||'%') order by q.ques_id desc";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setString(1, search);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				PostQuestions ques = new PostQuestions();
				ques.setUsername(rs.getString("uname"));
				ques.setDesig(rs.getString("designation"));
				ques.setQuestionId(rs.getInt("ques_id"));
				ques.setQuestion(rs.getString("ques"));
				ques.setTitle(rs.getString("title"));
				ques.setDatecreated(rs.getDate("date_created"));
				ques.setDateUpdated(rs.getDate("date_update"));
				allQuestions.add(ques);
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());

		}
		return allQuestions;
	}
	public String postQuestion(Questions obj) {
		String s=null;
		String cmd = "insert into questions(u_id,ques_id,ques,title,date_created,date_update)values(?,?,?,?,sysdate,sysdate)";
		try {
			int q_id = this.generateQuestionId();
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setInt(1, obj.getUserId());
			preparedStatement.setInt(2, q_id);
			preparedStatement.setString(3, "<pre>"+obj.getQuestion()+"</pre>");
			preparedStatement.setString(4, obj.getTitle());
			int p=preparedStatement.executeUpdate();
			if(p>0) {
				s="Question posted successfully";
				connection.commit();
				
			}
		} catch (SQLException e) {

			logger.error(e.getMessage());
			s= "Questions not posted";
		}
		return s;
	}
	
	public ArrayList<PostQuestions> viewAllQuestionCat(String category) {
		ArrayList<PostQuestions> allQuestions = new ArrayList<PostQuestions>();
		
		String cmd = "select u.uname uname,u.designation designation,q.ques_id ques_id,q.ques ques,"
				+ "q.title title,q.date_created date_created,q.date_update date_update "
				+ "from questions q inner join users u on u.u_id=q.u_id where q.title=? order by q.ques_id desc";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setString(1, category);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				PostQuestions ques = new PostQuestions();
				ques.setUsername(rs.getString("uname"));
				ques.setDesig(rs.getString("designation"));
				ques.setQuestionId(rs.getInt("ques_id"));
				ques.setQuestion(rs.getString("ques"));
				ques.setTitle(rs.getString("title"));
				ques.setDatecreated(rs.getDate("date_created"));
				ques.setDateUpdated(rs.getDate("date_update"));
				allQuestions.add(ques);
			}
			
		} catch (SQLException e) {

			logger.error(e.getMessage());
		}

		return allQuestions;
	}
	

	
	public ArrayList<PostQuestions> viewAllQuestionUid(int uid) {
		ArrayList<PostQuestions> allQuestions = new ArrayList<PostQuestions>();
		String cmd = "select u.uname uname,u.designation designation,q.ques_id ques_id,q.ques ques,"
				+ "q.title title,q.date_created date_created,q.date_update date_update "
				+ "from questions q inner join users u on u.u_id=q.u_id where u.u_id=? order by q.ques_id desc";
		try {
			preparedStatement = connection.prepareStatement(cmd);
			preparedStatement.setInt(1, uid);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				PostQuestions ques = new PostQuestions();
				ques.setUsername(rs.getString("uname"));
				ques.setDesig(rs.getString("designation"));
				ques.setQuestionId(rs.getInt("ques_id"));
				ques.setQuestion(rs.getString("ques"));
				ques.setTitle(rs.getString("title"));
				ques.setDatecreated(rs.getDate("date_created"));
				ques.setDateUpdated(rs.getDate("date_update"));
				allQuestions.add(ques);
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}

		return allQuestions;
	}
	
}
