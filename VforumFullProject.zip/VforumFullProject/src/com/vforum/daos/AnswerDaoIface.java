package com.vforum.daos;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.vforum.model.PostAnswers;
import com.vforum.model.Questions;

public interface AnswerDaoIface {
	public int generateAnswerId();

	public ArrayList<PostAnswers> allrecentquesanswers(int qid);

	public ArrayList<Questions> viewQuestion(int uid);

	public void answerQuestion(int quesid, int userid, String answer);

	public ResultSet viewAllAnswersWithQuesUid(int uid);
}
