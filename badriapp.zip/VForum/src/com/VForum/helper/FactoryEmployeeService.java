package com.VForum.helper;

public class FactoryEmployeeService {

public static FactoryService createEmployeeService(){
		
		EmployeeService employeeService=new EmployeeServiceImpl();
		return employeeService;
	}
}
