package com.VForum.helper;

public class FactoryEmployeeDAO {

public static EmployeeDAO createEmployeeDAO(){
		
		EmployeeDAO employeeDAO=new MemoryEmployeeDAOImpl();
		return employeeDAO;
		
	}
}
