package com.VForum.ui;

import java.util.Scanner;

import com.VForum.controller.EmployeeController;
import com.VForum.view.EmployeeView;

public class ConsoleUI {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("1. Register");
		System.out.println("2. view");
		System.out.print("Enter option:");
		int option=scanner.nextInt();
		EmployeeView employeeView=new EmployeeView();

		if(option==1){
		employeeView.registerEmployeeForm();
		}
		if(option==2){
       EmployeeController employeeController=new EmployeeController();
       employeeController.viewEmployee();
		}

	}
}
