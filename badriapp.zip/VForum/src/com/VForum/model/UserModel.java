package com.VForum.model;

public class UserModel {
	
	public UserModel()
	{
		
	}

}
