package com.VForum.dao;

public class EmployeeDAOImpl implements EmployeeDAO {

}
