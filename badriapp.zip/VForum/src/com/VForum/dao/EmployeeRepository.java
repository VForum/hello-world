package com.VForum.dao;

import java.util.ArrayList;
import java.util.List;

import com.VForum.entities.Employee;

public class EmployeeRepository implements EmployeeDAO {

private static List<Employee> employees=new ArrayList<Employee>();
	
	public static boolean add(Employee employee){
		return employees.add(employee);
	}
	
	public static List<Employee> get(){
		return employees;
	}

	@Override
	public boolean persistEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Employee> viewEmployees() {
		// TODO Auto-generated method stub
		return null;
	}
}
