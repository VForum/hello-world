package com.VForum.dao;

import java.util.List;

import com.VForum.entities.Employee;

public interface EmployeeDAO {

	public boolean persistEmployee(Employee employee);
	public List<Employee> viewEmployees();
}
