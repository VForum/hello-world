package com.VForum.dao;

public interface PostDAO {

}
