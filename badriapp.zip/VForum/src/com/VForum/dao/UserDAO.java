package com.VForum.dao;

public interface UserDAO {

}
