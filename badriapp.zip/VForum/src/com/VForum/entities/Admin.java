package com.VForum.entities;

public class Admin extends User {
	
	public Admin()
	{
		
	}

	private String adminId;

	public String getAdminId() {
		return adminId;
	}

	public void setAdminId(String adminId) {
		adminId = adminId;
	}
	
}
