package com.VForum.controller;

public class EmployeeController {

	private EmployeeService employeeService;
	public EmployeeController(){
		this.employeeService=FactoryEmployeeService.createEmployeeService();
		
	}
	
	public void storeEmployee(EmployeeModel employeeModel){
		
		boolean result=employeeService.storeEmployeeService(employeeModel);
		EmployeeView employeeView=new EmployeeView();
		if(result){
			employeeView.storeSuccessful();
		}else{
			
			employeeView.storeUnSuccessful();
		}
		
	}
	

	public void viewEmployee(){
		
		List<EmployeeModel> employeeModelList=employeeService.retrieveEmployeeService();
		EmployeeView employeeView=new EmployeeView();
		employeeView.displayEmployeeDetails(employeeModelList);
	}
}
