package com.VForum.service;

public class AdminServiceImpl implements AdminService {

}
