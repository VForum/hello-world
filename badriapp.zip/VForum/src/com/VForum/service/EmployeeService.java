package com.VForum.service;

public interface EmployeeService {

	public boolean storeEmployeeService(EmployeeModel employeemodel);
	public List<EmployeeModel> retrieveEmployeeService();
}
