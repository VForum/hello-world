package com.VForum.service;

import com.VForum.entities.Employee;
import com.VForum.model.EmployeeModel;

public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDAO employeeDAO=null;
	public EmployeeServiceImpl(){
		this.employeeDAO=FactoryEmployeeDAO.createEmployeeDAO();
		
	}
	
	
	@Override
	public boolean storeEmployeeService(EmployeeModel employeemodel) {
		// TODO Auto-generated method stub
		
		Employee employee=new Employee();
		employee.setUserId(employeemodel.getUserId());
		employee.setFirstName(employeemodel.getFirstName());
		employee.setLastName(employeemodel.getLastName());
		employee.setEmailId(employeemodel.getEmailId());
		employee.setPhoneNumber(employeemodel.getPhoneNumber());
		employee.setPassword(employeemodel.getPassword());
		employee.setDateOfBirth(employeemodel.getDateOfBirth());
		employee.setDesignation(employeemodel.getDesignation());
		
		return employeeDAO.persistEmployee(employee);
		
		
		
		
	}

	@Override
	public List<StudentModel> retrieveStudentService() {
		// TODO Auto-generated method stub
		List<Student> studentList=studentDAO.viewStudents();
		
		StudentModel studentModel=new StudentModel();
		List<StudentModel> studentModelList=new ArrayList<StudentModel>();
		
		for(Student student:studentList){
			
			StudentModel studentMdl=new StudentModel();
			studentMdl.setRollNo(student.getRollNo());
			studentMdl.setCourseId(student.getCourse().getCourseId());
			studentMdl.setFirstName(student.getStudentDetails().getFirstName());
			studentMdl.setLastName(student.getStudentDetails().getLastName());
			studentMdl.setEmail(student.getStudentDetails().getEmail());
			studentMdl.setPhoneNumber(student.getStudentDetails().getEmail());
			studentModelList.add(studentMdl);
		}
		return studentModelList;
	}

}
