package com.VForum.view;

public class AdminView {

}
