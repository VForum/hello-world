package com.VForum.view;

import java.util.List;
import java.util.Scanner;

import com.VForum.controller.EmployeeController;
import com.VForum.model.EmployeeModel;

public class EmployeeView {

	public void registerEmployeeForm(){
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter user id");
		int userId=scanner.next();
		
		System.out.print("Enter your FirstName:");
		String firstName=scanner.next();
		
		System.out.print("Enter your LastName:");
		String lastName=scanner.next();
		
		System.out.print("Enter your Email Address:");
		String emailId=scanner.next();
		

		System.out.print("Enter your PhoneNumber:");
		String phoneNumber=scanner.next();
		
		System.out.print("Enter your designation:");
		String designation=scanner.next();
		
		System.out.print("Enter your password :");
		int pasword=scanner.nextInt();
		
		System.out.print("Enter your date of birth:");
		String dateOfBirth=scanner.next();
		
		EmployeeModel employeeModel=new EmployeeModel();
		employeeModel.setUserId(userId);
		employeeModel.setFirstName(firstName);
		employeeModel.setLastName(lastName);
		employeeModel.setEmailId(emailId);
		employeeModel.setPassword(password);
		employeeModel.setPhoneNumber(phoneNumber);
		employeeModel.setDesignation(designation);
		employeeModel.setDateOfBirth(dateOfBirth);
		
		
		EmployeeController employeeController=new EmployeeController();
		employeeController.storeEmployee(employeeModel);
		
	}
	
	
	public void storeSuccessful(){
		
		System.out.println("Employee registeration successful");
	}
	
    public void storeUnSuccessful(){
		
		System.out.println("Employee registeration unsuccessful");
	}
    
    
    
    public void displayEmployeeDetails(List<EmployeeModel> employeeModel){
    	
    	employeeModel.forEach(System.out::println);
    }
}
