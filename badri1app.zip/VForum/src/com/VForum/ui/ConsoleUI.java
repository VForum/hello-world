package com.VForum.ui;


import com.VForum.view.EmployeeView;

public class ConsoleUI {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeView employeeView=new EmployeeView();
		employeeView.mainMenu();


	}
}
