package com.VForum.helper;

import com.VForum.dao.EmployeeDAO;
import com.VForum.dao.EmployeeDAOImpl;

public class FactoryEmployeeDAO {

public static EmployeeDAO createEmployeeDAO(){
		
		EmployeeDAO employeeDAO=new EmployeeDAOImpl();
		return employeeDAO;
		
	}
}
