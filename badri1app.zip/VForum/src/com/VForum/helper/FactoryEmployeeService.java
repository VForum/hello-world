package com.VForum.helper;

import com.VForum.service.EmployeeService;
import com.VForum.service.EmployeeServiceImpl;

public class FactoryEmployeeService {

public static EmployeeService createEmployeeService(){
		
		EmployeeService employeeService=new EmployeeServiceImpl();
		return employeeService;
	}
}
