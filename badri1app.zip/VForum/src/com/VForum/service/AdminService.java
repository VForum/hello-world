package com.VForum.service;

public interface AdminService {

}
