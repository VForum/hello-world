package com.VForum.service;

import java.util.ArrayList;
import java.util.List;

import com.VForum.dao.EmployeeDAO;
import com.VForum.entities.Employee;
import com.VForum.helper.FactoryEmployeeDAO;
import com.VForum.model.EmployeeModel;

public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDAO employeeDAO=null;
	public EmployeeServiceImpl(){
		this.employeeDAO=FactoryEmployeeDAO.createEmployeeDAO();
		
	}
	
	
	@Override
	public boolean storeEmployeeService(EmployeeModel employeemodel) {
		// TODO Auto-generated method stub
		
		Employee employee=new Employee();
		employee.setEmployeeId(employeemodel.getEmployeeId());
		employee.setUserId(employeemodel.getUserId());
		employee.setFirstName(employeemodel.getFirstName());
		employee.setLastName(employeemodel.getLastName());
		employee.setEmailId(employeemodel.getEmailId());
		employee.setPhoneNumber(employeemodel.getPhoneNumber());
		employee.setPassword(employeemodel.getPassword());
		employee.setDateOfBirth(employeemodel.getDateOfBirth());
		employee.setDesignation(employeemodel.getDesignation());
		
		return employeeDAO.persistEmployee(employee);
		
		
		
		
	}

	@Override
	public List<EmployeeModel> retrieveEmployeeService() {
		// TODO Auto-generated method stub
		List<Employee> employeeList=employeeDAO.viewEmployees();
		
		EmployeeModel employeeMdl=new EmployeeModel();
		List<EmployeeModel> employeeModelList=new ArrayList<EmployeeModel>();
		
		for(Employee employee:employeeList){
			
			
			employeeMdl.setUserId(employee.getUserId());
			employeeMdl.setPassword(employee.getPassword());
			employeeMdl.setFirstName(employee.getFirstName());
			employeeMdl.setLastName(employee.getLastName());
			employeeMdl.setEmailId(employee.getEmailId());
			employeeMdl.setDateOfBirth(employee.getDateOfBirth());
			employeeMdl.setPhoneNumber(employee.getPhoneNumber());
			employeeModelList.add(employeeMdl);
		}
		return employeeModelList;
	}

}
