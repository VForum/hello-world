package com.VForum.service;

import java.util.List;

import com.VForum.model.EmployeeModel;

public interface EmployeeService {

	public boolean storeEmployeeService(EmployeeModel employeemodel);
	public List<EmployeeModel> retrieveEmployeeService();
}
