package com.VForum.entities;

public class Answer {

	public String answerId;
	//public answerDateTime

	public String getAnswerId() {
		return answerId;
	}

	public void setAnswerId(String answerId) {
		this.answerId = answerId;
	}
	
}
