package com.VForum.entities;

public class Thread {

		public String threadId;
		public String threadType;
		public String threadName;
		public String getThreadId() {
			return threadId;
		}
		public void setThreadId(String threadId) {
			this.threadId = threadId;
		}
		public String getThreadType() {
			return threadType;
		}
		public void setThreadType(String threadType) {
			this.threadType = threadType;
		}
		public String getThreadName() {
			return threadName;
		}
		public void setThreadName(String threadName) {
			this.threadName = threadName;
		}
		
}
