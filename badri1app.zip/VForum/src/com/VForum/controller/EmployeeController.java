package com.VForum.controller;

import java.util.List;

import com.VForum.helper.FactoryEmployeeService;
import com.VForum.model.EmployeeModel;
import com.VForum.service.EmployeeService;
import com.VForum.view.EmployeeView;

public class EmployeeController {

	private EmployeeService employeeService;
	public EmployeeController(){
		this.employeeService=FactoryEmployeeService.createEmployeeService();
		
	}
	
	public void storeEmployee(EmployeeModel employeeModel){
		
		boolean result=employeeService.storeEmployeeService(employeeModel);
		EmployeeView employeeView=new EmployeeView();
		if(result){
			employeeView.storeSuccessful();
		}else{
			
			employeeView.storeUnSuccessful();
		}
		
	}
	

	public void viewEmployee(){
		
		List<EmployeeModel> employeeModelList=employeeService.retrieveEmployeeService();
		EmployeeView employeeView=new EmployeeView();
		employeeView.displayEmployeeDetails(employeeModelList);
	}
}
