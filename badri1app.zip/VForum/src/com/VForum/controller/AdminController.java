package com.VForum.controller;

public class AdminController {

}
