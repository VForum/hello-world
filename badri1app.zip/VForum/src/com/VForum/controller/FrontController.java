package com.VForum.controller;

public class FrontController {

}
