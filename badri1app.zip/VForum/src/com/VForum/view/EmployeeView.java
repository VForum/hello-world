package com.VForum.view;

import java.util.List;
import java.util.Scanner;
import com.VForum.controller.EmployeeController;
import com.VForum.model.EmployeeModel;

public class EmployeeView {
	public void mainMenu(){
	
	Scanner scanner=new Scanner(System.in);
	System.out.println("1. Employee registration");
	System.out.println("2. View employees");
	System.out.print("Enter option:");
	int option=scanner.nextInt();
	EmployeeView employeeView=new EmployeeView();

	if(option==1){
	employeeView.registerEmployeeForm();
	}
	if(option==2){
       EmployeeController employeeController=new EmployeeController();
       employeeController.viewEmployee();
	}
	
	
}



	public void registerEmployeeForm(){
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter employee id");
		int employeeId=scanner.nextInt();
		System.out.print("Enter user id");
		String userId=scanner.next();
		
		System.out.print("Enter your FirstName:");
		String firstName=scanner.next();
		
		System.out.print("Enter your LastName:");
		String lastName=scanner.next();
		
		System.out.print("Enter your Email Address:");
		String emailId=scanner.next();
		

		System.out.print("Enter your PhoneNumber:");
		String phoneNumber=scanner.next();
		
		System.out.print("Enter your designation:");
		String designation=scanner.next();
		
		System.out.print("Enter your password :");
		String password=scanner.next();
		
		System.out.print("Enter your date of birth:");
		String dateOfBirth=scanner.next();
		
		EmployeeModel employeeModel=new EmployeeModel();
		employeeModel.setEmployeeId(employeeId);
		employeeModel.setUserId(userId);
		employeeModel.setFirstName(firstName);
		employeeModel.setLastName(lastName);
		employeeModel.setEmailId(emailId);
		employeeModel.setPassword(password);
		employeeModel.setPhoneNumber(phoneNumber);
		employeeModel.setDesignation(designation);
		employeeModel.setDateOfBirth(dateOfBirth);
		scanner.close();
		
		EmployeeController employeeController=new EmployeeController();
		employeeController.storeEmployee(employeeModel);
		mainMenu();
	}
	
	
	public void storeSuccessful(){
		
		System.out.println("Employee registeration successful");
	}
	
    public void storeUnSuccessful(){
		
		System.out.println("Employee registeration unsuccessful");
	}
    
    
    
    public void displayEmployeeDetails(List<EmployeeModel> employeeModel){
    	
    	employeeModel.forEach(System.out::println);
    }

}
