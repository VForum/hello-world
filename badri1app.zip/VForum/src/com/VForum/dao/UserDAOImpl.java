package com.VForum.dao;

public class UserDAOImpl implements UserDAO {

}
