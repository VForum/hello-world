package com.VForum.dao;

import java.util.ArrayList;
import java.util.List;

import com.VForum.entities.Employee;

public class EmployeeRepository {

private static List<Employee> employees=new ArrayList<Employee>();
	
	public static boolean add(Employee employee){
		return employees.add(employee);
	}
	
	public static List<Employee> get(){
		return employees;
	}

}
