package com.VForum.dao;

public class ThreadDAOImpl implements ThreadDAO {

}
