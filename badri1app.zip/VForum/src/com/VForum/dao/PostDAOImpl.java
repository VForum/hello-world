package com.VForum.dao;

public class PostDAOImpl implements PostDAO {

}
