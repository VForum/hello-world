package com.VForum.dao;

import java.util.List;

import com.VForum.entities.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public boolean persistEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Employee> viewEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
