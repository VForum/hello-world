package com.VForum.dao;

public class AnswerDAOImpl implements AnswerDAO {

	
	
	
	
}
