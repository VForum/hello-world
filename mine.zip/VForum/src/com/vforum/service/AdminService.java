package com.vforum.service;

import java.util.List;

import com.vforum.model.RegisterEmployeeModel;

public interface AdminService {

		public List<RegisterEmployeeModel> retrieveEmployees();
	}


