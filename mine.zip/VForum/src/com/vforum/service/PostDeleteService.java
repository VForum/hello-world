package com.vforum.service;

import com.vforum.model.PostModel;

public interface PostDeleteService {
	public String deletePosts(PostModel postModel);

}
