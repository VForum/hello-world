
package com.vforum.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.vforum.dao.AdminDao;
import com.vforum.entities.Employees;
import com.vforum.helper.FactoryAdminDB;
import com.vforum.model.RegisterEmployeeModel;

public class AdminServiceImpl implements AdminService {
	private AdminDao adminDao;
	
	public AdminServiceImpl() {
		this.adminDao=FactoryAdminDB.createAdminDao();
		
	}

	@Override
	public List<RegisterEmployeeModel> retrieveEmployees() {
		// TODO Auto-generated method stub
		List<RegisterEmployeeModel> employeesModelList=new ArrayList<>();
		
			List<Employees> employeesList;
			try {
				employeesList = adminDao.getEmployeeDetails();
			
			for(Employees employees:employeesList)
			{
				RegisterEmployeeModel employeesModel=new RegisterEmployeeModel();
				employeesModel.setEmployeeUid(employees.getEmployeeUid());
				employeesModel.setFirstName(employees.getFirstName());
				employeesModel.setLastName(employees.getLastName());
				employeesModel.setEmail(employees.getEmail());
				employeesModel.setPhoneNumber(employees.getPhoneNumber());
				employeesModel.setDesignation(employees.getDesignation());
				//employeesModel.setDob(employees.getDob());
				employeesModelList.add(employeesModel);
			}
			} catch (ClassNotFoundException | SQLException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return employeesModelList;
	}
}
