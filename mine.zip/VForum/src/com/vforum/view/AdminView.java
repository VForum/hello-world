package com.vforum.view;

import java.util.List;
import java.util.Scanner;

import com.vforum.controller.AdminController;
import com.vforum.model.LoginModel;
import com.vforum.model.PostModel;
import com.vforum.model.RegisterEmployeeModel;

public class AdminView {

	private MainView mainView=new MainView();

	public void showEmployees(List<RegisterEmployeeModel> model,LoginModel loginModel){
	//System.out.println("=====================================================================================================================");
		//System.out.format("EmployeeUId","FirstName","LastName","Email","PhoneNumber","Desiganation");
		//System.out.println("=====================================================================================================================");
		for(RegisterEmployeeModel models:model) {
			System.out.format("%9s,%12s,%12s,%12s,%12s,%12s\n",models.getEmployeeUid(),models.getFirstName(),models.getLastName(),models.getEmail(),models.getPhoneNumber(),models.getDesignation());
	//System.out.println("\n");
		}
		mainView.viewAdminMainMenu(loginModel);
	}

}