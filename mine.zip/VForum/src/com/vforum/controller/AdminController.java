package com.vforum.controller;

import java.util.List;

import com.vforum.helper.FactoryAdminDB;
import com.vforum.model.LoginModel;
import com.vforum.model.PostModel;
import com.vforum.model.RegisterEmployeeModel;
import com.vforum.service.AdminService;
import com.vforum.view.AdminView;
import com.vforum.view.MainView;

public class AdminController {
	
	private AdminService adminService;
	
	AdminView adminView=new AdminView();
	
	public AdminController()
	{
	 this.adminService=FactoryAdminDB.createAdminService();
	}
	public void viewEmployees(LoginModel loginModel) {
		List<RegisterEmployeeModel> models=adminService.retrieveEmployees();
		MainView mainView=new MainView();
		adminView.showEmployees(models,loginModel);
	}

	
}
