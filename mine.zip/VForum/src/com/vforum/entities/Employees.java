package com.vforum.entities;
/**
 * 
 * @author sathish
 *
 *EMP_UID      NOT NULL VARCHAR2(20) 
FIRST_NAME   NOT NULL VARCHAR2(30) 
LAST_NAME    NOT NULL VARCHAR2(30) 
EMAIL        NOT NULL VARCHAR2(50) 
PHONE_NUMBER NOT NULL VARCHAR2(15) 
DESIGNATION           VARCHAR2(25) 
EMP_ID       NOT NULL NUMBER(10)   
PASSWORD     NOT NULL VARCHAR2(20) 
 */
public class Employees {

	private String employeeUid;
	private String firstName;
	private String lastName;
	private String email;
	private String phoneNumber;
	private String designation;
	//private String dob;
	private String password;
	
	public Employees() { }

	public String getEmployeeUid() {
		return employeeUid;
	}

	public void setEmployeeUid(String employeeUid) {
		this.employeeUid = employeeUid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	//public String getDob() {
		//return dob;
	//}

	//public void setDob(String dob) {
		//this.dob = dob;
	//}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((designation == null) ? 0 : designation.hashCode());
		//result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((employeeUid == null) ? 0 : employeeUid.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((phoneNumber == null) ? 0 : phoneNumber.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employees other = (Employees) obj;
		if (designation == null) {
			if (other.designation != null)
				return false;
		} else if (!designation.equals(other.designation))
			return false;
		//if (dob == null) {
			//if (other.dob != null)
				//return false;
		//} else if (!dob.equals(other.dob))
			//return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (employeeUid == null) {
			if (other.employeeUid != null)
				return false;
		} else if (!employeeUid.equals(other.employeeUid))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (phoneNumber == null) {
			if (other.phoneNumber != null)
				return false;
		} else if (!phoneNumber.equals(other.phoneNumber))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Employees [employeeUid=" + employeeUid + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", email=" + email + ", phoneNumber=" + phoneNumber + ", designation=" + designation + ", password=" + password + "]";
	}


}
