package com.vforum.dao;

import java.sql.SQLException;

import com.vforum.model.PostQuestionModel;

public interface PostDeleteDAO {
	public boolean deletePost(PostQuestionModel postQuestionModel)throws ClassNotFoundException, SQLException;
}
