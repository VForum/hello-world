package com.vforum.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.vforum.integrate.ConnectionManager;
import com.vforum.model.PostModel;
import com.vforum.model.PostQuestionModel;

public class PostDeleteDAOImpl implements PostDeleteDAO {
PostModel postModel=new PostModel();

	@Override
	public boolean deletePost(PostQuestionModel postQuestionModel) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=
				connection.prepareStatement("delete from  where post_id=?");
		statement.setInt(1,postModel.getPostId());
		int rows=statement.executeUpdate();
		ConnectionManager.closeConnection();
		if(rows>0)
			return true;
		else
		return false;
	}

}
