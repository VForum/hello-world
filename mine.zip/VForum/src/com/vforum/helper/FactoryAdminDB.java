package com.vforum.helper;

import com.vforum.dao.AdminDao;
import com.vforum.dao.AdminDaoImpl;
import com.vforum.dao.PostDeleteDAO;
import com.vforum.dao.PostDeleteDAOImpl;
import com.vforum.service.AdminService;
import com.vforum.service.AdminServiceImpl;

public class FactoryAdminDB {
	
	public static AdminDao createAdminDao(){
		AdminDao adminDao=new AdminDaoImpl();
		return adminDao;
		
	}
	public static AdminService createAdminService(){
		AdminService adminService=
				new AdminServiceImpl();
		return adminService;
	}
	public static PostDeleteDAO createPostDao()
	{
		PostDeleteDAO postDeleteDAO=new PostDeleteDAOImpl();
		return postDeleteDAO;
	}
	
	

}
