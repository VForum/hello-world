package com.vforum.ui;

import com.vforum.view.MainView;

public class ConsoleUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainView mainView=new MainView();
		mainView.mainMenu();
	}

}
